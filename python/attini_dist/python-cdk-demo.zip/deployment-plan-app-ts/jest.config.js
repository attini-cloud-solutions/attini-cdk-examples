module.exports = {
  testEnvironment: 'node'
}
