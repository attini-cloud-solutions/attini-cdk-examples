package attini.example;

import software.amazon.awscdk.App;
import software.amazon.awscdk.StackProps;

public class DemoApp {

    public static final String STACK_ID = "AttiniJavaDemoStack";

    public static void main(final String[] args) {
        App app = new App();

        new DemoStack(app, STACK_ID, StackProps.builder().build());

        app.synth();
    }
}

