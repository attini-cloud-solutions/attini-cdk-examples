package attini.example.deploymentplan;

import java.util.List;
import java.util.Map;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import attini.cdk.AttiniCdk;
import attini.cdk.AttiniCdkProps;
import attini.cdk.AttiniDeploymentPlanStack;
import attini.cdk.AttiniPayload;
import attini.cdk.AttiniRunner;
import attini.cdk.AttiniRunnerJob;
import attini.cdk.AttiniRunnerJobProps;
import attini.cdk.AttiniRunnerProps;
import attini.cdk.DeploymentPlan;
import attini.cdk.DeploymentPlanProps;
import attini.cdk.RunnerConfiguration;
import attini.cdk.Startup;
import attini.example.DemoApp;
import attini.example.DemoStack;
import software.amazon.awscdk.App;
import software.amazon.awscdk.StackProps;
import software.constructs.Construct;

public class DeploymentPlanStack extends AttiniDeploymentPlanStack {

    protected DeploymentPlanStack(@NotNull Construct scope, @NotNull String id) {
        this(scope, id, null);
    }

    protected DeploymentPlanStack(@NotNull Construct scope,
                                  @NotNull String id,
                                  @Nullable StackProps props) {
        super(scope, id, props);

        AttiniRunner runner = new AttiniRunner(this,
                                               "DemoRunner",
                                               AttiniRunnerProps.builder()
                                                                .startup(Startup.builder()
                                                                                .commands(List.of("yum install maven -y"))
                                                                                .build())
                                                                .runnerConfiguration(RunnerConfiguration.builder()
                                                                                                        .idleTimeToLive(
                                                                                                                3600)
                                                                                                        .build())
                                                                .build());

        AttiniCdk deployCdkApp = new AttiniCdk(this,
                                               "DeployCdkApp",
                                               AttiniCdkProps.builder()
                                                             .runner(runner.getRunnerName()).path("./")
                                                             .build());

        AttiniRunnerJob echoSnsResource = new AttiniRunnerJob(this,
                                                              "EchoSnsResource",
                                                              AttiniRunnerJobProps.builder()
                                                                                  .environment(Map.of("ENV",
                                                                                                      AttiniPayload.environment(),
                                                                                                      "SNS_ARN",
                                                                                                      deployCdkApp.getOutput(
                                                                                                              DemoApp.STACK_ID,
                                                                                                              DemoStack.SNS_ARN_OUTPUT_KEY)))
                                                                                  .commands(List.of(
                                                                                          "echo deployed topic with arn ${SNS_ARN} to ${ENV}"))
                                                                                  .build());

        new DeploymentPlan(this,
                           "DeploymentPlan",
                           DeploymentPlanProps.builder().definition(deployCdkApp.next(echoSnsResource)).build());
    }

    public static void main(final String[] args) {
        App app = new App();

        new DeploymentPlanStack(app, "DeploymentPlanStack", StackProps.builder().build());

        app.synth();
    }

}
